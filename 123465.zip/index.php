<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CMM </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

    <img src="img/1.jpg" width="20%"  class="img-fluid" srcset=""> <center> <h1> Central de Medios Municipales</h1> </center>

    <br>
  <div class="row">
    <div class="col-4">
    <div class="card-columns">
    <div class="card">	

        <div class="card-body">
      
	</div>
    </div>
    </div>
</div>
<?php
include ("conexion.php");



$query = "SELECT * FROM `publiv`";
$resultado = mysqli_query($db,$query);
if($resultado){
  while ($row = $resultado->fetch_array()) {
     $id= $row{'id'};
     $titulo= $row{'titulo'};
     $des= $row{'des'};
     $f= $row['files'];
 

?>
<div class="card" style="width: 18rem;">
  <h2><?php echo $id ?> </h2>
  <img src="img/<?php echo $f;?>" class="card-img-top" alt="...">
  <div class="card-body">
  <img src="<?php echo $f;?>" class="img-thumbnail" width ="30%" alt="...">
    <h5 class="card-title"><?php echo $titulo;?></h5>
    <p class="card-text"><?php echo $des;?></p>
    <a href="#" class="btn btn-danger">DEscargar</a>
  </div>
</div>
<?php
 }
}
?>

    <div class="row">
    <div class="col-4">
    <div class="card-columns">
    <div class="card">	
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
 