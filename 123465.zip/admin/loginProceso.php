<?php 
	session_start();
	include_once '../conexion/conexion.php';
	$usuario = $_POST['usuario'];
	$contrasena = $_POST['password'];
	$sentencia = $bd->prepare('select * from usuarios where 
								usuario = ? and pass = ?;');
	$sentencia->execute([$usuario, $contrasena]);
	$datos = $sentencia->fetch(PDO::FETCH_OBJ);
	//print_r($datos);

	if ($datos === FALSE) {
		header('Location: index.php');
	}elseif($sentencia->rowCount() == 1){
		$_SESSION['nombre'] = $datos->nombre_usu;
		header('Location:home.php');
	}
?>