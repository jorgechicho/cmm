<?php
//Incluimos el fichero de conexión a MySQL
include "conexion.php";
$nombre = $_POST["titulo"];
$des = $_POST["des"];

                    $insertarsql = "INSERT INTO publiv(titulo, des ) VALUES ('$nombre','$des')";
                    $resultado= mysqli_query($db, $insertarsql);
                    if ($resultado) {
                      
						echo ("<script LANGUAGE='JavaScript'>
						window.alert('Publicacion guardada');
						window.location.href='imagenes.php';
						</script>");	
						
						
										
						# echo '<script type="text/javascript">alert("Publicacion guardada ");</script>';; 
                    #}else {
                     # printf("Errormessage: %s/n", mysqli_error($db));
                     
                     }else{
                      echo " oooh! hubo un prmoblema";
                     }
                
			closedir($dir); //Cerramos la conexion con la carpeta destino
		



    
 
    ?>