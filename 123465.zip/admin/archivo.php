<?php
include "conexion.php";

$nombre = $_POST["titulo"];
$des = $_POST["des"];

if($_FILES["files"] && $_FILES["rar"]){
  
  $nombase = basename($_FILES["files"]["name"]);
  $rar = basename($_FILES["rar"]["name"]);
  $nomfinal = date("m-d-a")."-".date("H-i-s"). "-" . $nombase;
  $rarfinal = date("m-d-a"). "-".date("H-i-s"). "-". $rar;
  $ruta="img/". $nomfinal;
  $rut="rar/". $rarfinal;
  $subir= move_uploaded_file($_FILES["files"]["tmp_name"], $ruta); 
  $sub= move_uploaded_file($_FILES["rar"]["tmp_name"], $rut); 
  if($subir && $sub){
    $insertarsql = "INSERT INTO publiv(titulo, des ,files, rar) VALUES ('$nombre','$des','$ruta', '$rut')";
    $resultado= mysqli_query($db, $insertarsql);
    if ($resultado) {
      echo "se guarda correctamente"; 
    #}else {
     # printf("Errormessage: %s/n", mysqli_error($db));
     
     }else{
      echo " oooh! hubo un prmoblema";
     }
  }    
     
     
      #"<script>alert('el archivo se subio correctamente'); window.location='home.php'</scrpit>";


     # printf("Errormessage: %s/n", mysqli_error($db));
}


    
         
     #"<script>alert('el archivo se subio correctamente'); window.location='home.php'</scrpit>";


     # printf("Errormessage: %s/n", mysqli_error($db));





?>