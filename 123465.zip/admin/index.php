
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..//public/boostrap/bootstrap.min.css">
    <link rel="stylesheet" href="../public/css/menu.css">
</head>
   
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
         <!-- Icon -->    
    <div class="fadeIn first">
        <br>
      <img src="../img/1.jpg" width="350" />
      <h1>Central de Medios </h1>
    </div>

    <!-- Login Form -->
    <form action="loginProceso.php" method="post">
      <input type="text" id="usuario" class="fadeIn second" name="usuario" placeholder="usuario">
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="ingresar">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="https://munixela.gob.gt/">Munixela.gob.gt</a>
    </div>

  </div>
</div>
    


</body>
<script src="public/jquery/jquery-3.6.0.min.js"></script>
    <script src="public/boostrap/bootstrap.min.js/jquery-3.6.0.min.js"></script>
    <script src="public/boostrap/bootstrap.min.js/popper.min.js"></script>
 </html>