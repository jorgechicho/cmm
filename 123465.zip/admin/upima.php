<?php
//Incluimos el fichero de conexión a MySQL
include "conexion.php";

    if (isset($_POST["post"])){
	
foreach($_FILES["files"]['tmp_name'] as $key => $tmp_name)
	
		//condicional si el fuchero existe
		if($_FILES["files"]["name"][$key]) {
			// Nombres de archivos de temporales
			$archivonombre = $_FILES["files"]["name"][$key]; 
            $nomfinal = date("m-d-a")."-".date("H-i-s"). "-" . $archivonombre;
			$fuente = $_FILES["files"]["tmp_name"][$key]; 
			
			$carpeta = '../img/'; //Declaramos el nombre de la carpeta que guardara los archivos
			
			if(!file_exists($carpeta)){
				mkdir($carpeta, 0777) or die("Hubo un error al crear el directorio de almacenamiento");	
			}
			
			$dir=opendir($carpeta);
			$ruta = $carpeta.'/'.$nomfinal; //indicamos la ruta de destino de los archivos
			
	
			if(move_uploaded_file($fuente, $ruta)) {	
                #$ultimo= mysqli_insert_id(publiv);
                $insertarsql="INSERT INTO imagenes(file s) VALUES ('$ruta')";
                
                #$insertarsql = "INSERT INTO imagenes(files) VALUES ('$ruta')";
                    $resultado= mysqli_query($db, $insertarsql);
                    if ($resultado) {
                      
						echo ("<script LANGUAGE='JavaScript'>
						window.alert('Publicacion guardada');
						window.location.href='home.php';
						</script>");	
						
						
						
						
						
						# echo '<script type="text/javascript">alert("Publicacion guardada ");</script>';; 
                    #}else {
                     # printf("Errormessage: %s/n", mysqli_error($db));
                     
                     }else{
                      echo " oooh! hubo un prmoblema";
                     }
                  }    
  				} else {	
				echo "Se ha producido un error, por favor revise los archivos e intentelo de nuevo.<br>";
			}
			closedir($dir); //Cerramos la conexion con la carpeta destino
		
        }


    
 
    ?>