<?php 
	session_start();
	if (isset($_SESSION['nombre'])) {
		header('Location: home.php');
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CMM </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
	<a href="home.php" class="navbar-brand">Central de Meios Municipales</a>
                   <ul class="nav navbar-nav ms-auto">
                   <a class="nav-link active" aria-current="page" href="#">Publicaciones</a>
                     <a class="nav-link" href="home.php">Nueva Publicacion</a>
                     <a class="nav-link" href="#">Estadisticas</a>
                                       <li class="nav-item dropdown">
                    <a href="cerrar.php" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Cerrar sesion</a>
                    
                </li>
            </ul>
        </div>
    </div>
</nav>


<br>
<br>

  <div class="row">
    <div class="col-4">
    <div class="card-columns">
    <div class="card">
	<br>
<br>
<br>	
<img src="../img/1.jpg" width="100%"  class="img-fluid" srcset="">
        <div class="card-body">
	</div>
    </div>
</div>
</div>
    <div class="col-4">
    <div class="card-columns">
    <div class="card">
        <div class="cabodyrd-">
            <h4 class="card-title">imagen</h4>
            <p class="card-text">Ingrese los datos de la publicacion</p>
	<form action="upima.php" method="post" name="publicar" enctype="multipart/form-data">   
    <input type="file" class="form-control" id="files[]" name="files[]" multiple="" placholder="seleciona la portada">
    <br>
    <button type="submit" class="btn btn-primary" name= "post">Postear</button>
</form> 
</div>
    </div>
    </div>
    </div>


    <div class="row">
    <div class="col-4">
    <div class="card-columns">
    <div class="card">	

    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>